package demo;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/qp")
public class RequestParamDemo {
	@RequestMapping(value="hello")
	public String hello(@RequestParam (name="nm")String name){
		String str = " Hello, " + name;
		return str;
	}
	@RequestMapping(value="/add")
	public String add(@RequestParam (name="n1") int no1, @RequestParam (name="n2") int no2){
		String str = " Sum of "  + no1 + ", and " + no2 + " is " + (no1+no2);
		return str;
	}
}
