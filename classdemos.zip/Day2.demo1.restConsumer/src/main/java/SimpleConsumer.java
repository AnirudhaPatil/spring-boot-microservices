import org.springframework.web.client.RestTemplate;

public class SimpleConsumer {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		String url = "http://localhost:8080/";  //"https://reqres.in/api/users/2";
		RestTemplate resttemplate = new RestTemplate();
		String str = resttemplate.getForObject(url, String.class);
		System.out.println(str);
	}

}
