import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@SpringBootApplication(scanBasePackages="demo, conf")
public class SecureApplication {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(SecureApplication.class, args);
	}

}
