package conf;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

@Configuration
@EnableGlobalMethodSecurity(securedEnabled=true, prePostEnabled=true)
public class SecureConfiguration {
	
		@Autowired
		public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication()
			.withUser("user1").password("{noop}pass1").roles("stduser").and()
			.withUser("user2").password("{noop}pass2").roles("admin").and()
			.withUser("user3").password("{noop}pass3").roles("stduser","admin");
		/*	auth
				.jdbcAuthentication()
					.dataSource(dataSource)
					.withDefaultSchema()
					.withUser("user7").password("pass7").roles("user").and()
					.withUser("user8").password("pass8").roles("admin").and()
					.withUser("user9").password("pass9").roles("user","admin");
			*/		
		}
		/*
		 * private DataSource dataSource;
		 * 
		 * @Bean public DataSource getdataSource(){ return new
		 * DriverManagerDataSource("jdbc:hsqldb:hsql://localhost/","sa", "" ); }
		 * 
		 */
	}