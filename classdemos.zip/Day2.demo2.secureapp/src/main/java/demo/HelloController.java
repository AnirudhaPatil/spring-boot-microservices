package demo;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/")
public class HelloController {

	
	@GetMapping(value="/m1")
	@Secured(value="ROLE_admin")
	public String m1(){
		System.out.println("m1 invoked ..");
		return "<h1>M1 invoked </h1>";
	}
	
	@GetMapping(value="/m2")
	@Secured(value="ROLE_stduser")
	public String m2(){
		System.out.println("m2 invoked ..");
		return "<h1>M2 invoked </h1>";
	}
}
