
import java.nio.charset.Charset;
import java.util.Base64;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class SecureConsumer {
static String username="user3";
static String password="pass3";
public  static HttpHeaders createHeaders(){
		   return new HttpHeaders() {{
		         String auth = username + ":" + password;
		         byte[] encodedAuth =     Base64.getEncoder().encode(auth.getBytes(Charset.forName("US-ASCII")) );
		         
		         String authHeader = "Basic " + new String( encodedAuth );
		         set( "Authorization", authHeader );
		      }};
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		RestTemplate template = new RestTemplate();
		ResponseEntity<String> str;
		
		try {
			str= template.exchange ("http://localhost:8085/m1", HttpMethod.GET, new HttpEntity<>(createHeaders()), String.class);
			System.out.println("m1 returned = " + str.getBody());
		} catch (RestClientException e) {
		System.out.println("Errror in invoking m1 ");
		}
		try {
			str= template.exchange ("http://localhost:8085/m2", HttpMethod.GET, new HttpEntity<>(createHeaders()), String.class);
			System.out.println("m2 returned = " + str.getBody());
		} catch (RestClientException e) {
		System.out.println("Errror in invoking m2");
		}
		
		
	}

}
