package hello;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@Controller + @ResponseBody
@RestController
@RequestMapping(value="/")
public class FirstController {

//	@RequestMapping(value="/m1", method=RequestMethod.GET)
	@GetMapping
	public String method1(){
		System.out.println("in method1");
		return "<h1>GET method1 invoked </h1>";
	}
//	@RequestMapping(value="/m1",method=RequestMethod.POST)
	@PostMapping
	public String method2(){
		System.out.println("in method2");
		return "<h1>POST method2invoked </h1>";
	}
	@PutMapping
	public String method3(){
		System.out.println("in method3");
		return "<h1>PUT method3invoked </h1>";
	}
	@DeleteMapping
	public String method4(){
		System.out.println("in method4");
		return "<h1>DELETE method2invoked </h1>";
	}
	@RequestMapping(method=RequestMethod.HEAD)
	public String method5(){
		System.out.println("in method5");
		return "<h1>HEAD method2invoked </h1>";
	}
	@RequestMapping(method=RequestMethod.OPTIONS)
	public String method6(){
		System.out.println("in method6");
		return "<h1>OPTIONS method2invoked </h1>";
	}
	
}

