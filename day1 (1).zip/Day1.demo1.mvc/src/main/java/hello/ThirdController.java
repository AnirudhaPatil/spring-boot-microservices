package hello;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/third")
public class ThirdController {
	@GetMapping( produces = MediaType.TEXT_PLAIN_VALUE)
	public String method1(){
		System.out.println("in method1");
		return "plain text GET method1 invoked ";
	}
	@GetMapping( produces = MediaType.TEXT_HTML_VALUE)
	public String method2(){
		System.out.println("in method2");
		return "<h1> GET method2 invoked </h1>";
	}
	@GetMapping( produces = MediaType.APPLICATION_JSON_VALUE)
	public String method3(){
		System.out.println("in method3");
		return "{    \"glossary\": {  \"title\": \"example glossary\" }}";
	}
	@GetMapping( produces = MediaType.APPLICATION_XML_VALUE)
	public String method4(){
		System.out.println("in method4");
		return  "<note><to>Tove</to><from>Jani</from><heading>Reminder</heading><body>Don't forget me this weekend!</body></note>";
	}

	
}
