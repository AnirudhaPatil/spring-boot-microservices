package demo;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/pp")
public class PathParamDemo {
	
	@RequestMapping(value="/hello/{nm}")
	public String hello(@PathVariable(name="nm")String name){
		String str = " Hello, " + name;
		return str;
	}
	@RequestMapping(value="/add/{n1}/{n2}")
	public String add(@PathVariable(name="n1") int no1, @PathVariable(name="n2") int no2){
		String str = " Sum of "  + no1 + ", and " + no2 + " is " + (no1+no2);
		return str;
	}
}
