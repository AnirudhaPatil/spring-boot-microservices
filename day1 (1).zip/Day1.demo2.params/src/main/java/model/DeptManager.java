package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/dept")
public class DeptManager {

	private List<Dept> list = new ArrayList<Dept>();
	
	public DeptManager() {
		System.out.println("deptmanager con");
	}
/*for simple body params
 	@PostMapping()
	public String insert(Dept d){
		System.out.println("insert " + d);
		return "inserted";
	}
*/
	@PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE)
	public String insert(@RequestBody Dept d){
		System.out.println("insert " + d);
		list.add(d);
		return "inserted";
	}
	@GetMapping(produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Dept> list(){
		System.out.println("in list " + list.size());
		return list;
	}
	@GetMapping(value="/{dno}", produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Dept> listonedept(@PathVariable(name="dno")int deptno){
		System.out.println(" in listone " + deptno);
		Optional<Dept> deptopt= list.stream().filter((d)->d.getDeptno()==deptno).findFirst();
		if (deptopt.isPresent())
			return new ResponseEntity<Dept>(deptopt.get(),HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
}
