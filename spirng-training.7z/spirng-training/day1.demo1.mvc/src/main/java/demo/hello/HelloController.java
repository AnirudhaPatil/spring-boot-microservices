package demo.hello;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "parent/")
public class HelloController {

	@GetMapping(path = "met1", produces = MediaType.TEXT_HTML_VALUE)
	public String getMethod1() {
		return "<h1>GET: Greeeting from method 1</h1>";
	}

	@GetMapping(path = "met1", produces = MediaType.APPLICATION_XML_VALUE)
	public String getMethod2() {
		return "<note><to>Tove</to><from>Jani</from><heading>Reminder</heading><body>Don't forget me this weekend!</body></note>";
	}

	@GetMapping(path = "met1", produces = MediaType.APPLICATION_JSON_VALUE)
	public String getMethod3() {
		return " \"glossary\": { \"title\": \"example glossary\" }";
	}

	@PostMapping(path = "met1")
	public String postMethod1() {
		return "<h1>POST: Greeeting from method 1</h1>";
	}

	@PutMapping(path = "met1")
	public String putMethod1() {
		return "<h1>PUT: Greeeting from method 1</h1>";
	}

	@DeleteMapping(path = "met1")
	public String deletMethod1() {
		return "<h1>PUT: Greeeting from method 1</h1>";
	}

}