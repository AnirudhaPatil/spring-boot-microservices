package demo.modelExample;

public class Department {

	public Department() {
		super();
	}

	public Department(int _id) {
		super();
		this._id = _id;
	}

	int _id;
	String dept_name;
	String location;

	public int get_id() {
		return _id;
	}

	public void set_id(int _id) {
		this._id = _id;
	}

	public String getDept_name() {
		return dept_name;
	}

	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + _id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		if (_id != other._id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Department [_id=" + _id + ", dept_name=" + dept_name + ", location=" + location + "]";
	}

}
