package demo.modelExample;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/dept")
public class DepartmentController {

	private List<Department> dept_DB = new ArrayList<>();

	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Department>> getDepts() {
		return new ResponseEntity<>(this.dept_DB, HttpStatus.OK);
	}

	@GetMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Department> getDeptById(@PathVariable("id") int _id) {
		return new ResponseEntity<>(this.dept_DB.parallelStream().filter(d -> d.get_id() == _id).findFirst().get(),
				HttpStatus.OK);
	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> insertDeptIntoDB(@RequestBody Department dept) {
		this.dept_DB.add(dept);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> updateDeptIntoDB(@RequestBody Department dept) {

		int indexEle = this.dept_DB.indexOf(new Department(dept.get_id()));
		System.err.println(indexEle);
		this.dept_DB.set(indexEle, dept);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@DeleteMapping(path = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> deleteFromDB(@PathVariable("id") int _id) {

		int indexEle = this.dept_DB.indexOf(new Department(_id));
		System.err.println(indexEle);
		this.dept_DB.remove(indexEle);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
