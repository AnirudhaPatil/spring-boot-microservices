package demo.pathvariable;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/math")
public class PathController {

	@RequestMapping(path = "/add/{var1}/{var2}")
	public String getMethod(@PathVariable("var1") int var1, @PathVariable("var2") int var2) {
		System.out.println("hele");
		return String.valueOf(var1 + var2);
	}

}
