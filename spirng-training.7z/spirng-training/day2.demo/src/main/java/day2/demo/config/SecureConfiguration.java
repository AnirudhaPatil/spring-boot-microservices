package day2.demo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SecureConfiguration {
	
	PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();

	@Autowired
	public void globalConfiguration(AuthenticationManagerBuilder authBuilder) throws Exception {
		
		// {noop} -> default no-operation password encoder.
		
//		authBuilder.inMemoryAuthentication()
//		.withUser("anirudha_admin").password("{noop}admin").roles("ADMIN").and()
//		.withUser("anirudha_user").password("{noop}user").roles("USER").and()
//		.withUser("anirudha").password("{noop}anirudha").roles("USER", "ADMIN")
//		;
		
		
		/**
		 * In memory authentication procedure
		 */
		authBuilder.inMemoryAuthentication()
		  .withUser(buildUser("anirudha_admin", "admin", "ADMIN"))
		  .withUser(buildUser("anirudha_user", "user", "USER"))
		  .withUser("anirudha").password("{noop}anirudha").roles("USER", "ADMIN");
	}
	
	private UserDetails buildUser(String username, String password, String... role){
		final User.UserBuilder userBuilder = User.builder().passwordEncoder(encoder::encode);
	    UserDetails user = userBuilder
	            .username(username)
	            .password(password)
	            .roles(role)
	            .build();
	    
	    return user;

	}
}
