package day2.demo.secureservice;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "secure/")
public class SecureController {

	@GetMapping(path = "m1")
	@Secured(value = "ROLE_ADMIN")
	public String getMethod1() {
		return "<h1>GET: method 1</h1>";
	}

	@GetMapping(path = "m2")
	@Secured(value = "ROLE_USER")
	public String getMethod2() {
		return "<h1>GET: method 2</h1>";
	}

}