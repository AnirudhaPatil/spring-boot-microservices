package day2.oauth.consumer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
// @RequestMapping(path="/hello")
public class AuthController {

	@GetMapping(path = "/home")
	public String getMethod1() {
		return "/index.html";
	}
	
	@GetMapping(path = "/login")
	public String getLogin() {
		return "/login.html";
	}

	@GetMapping(path = "/info")
	@ResponseBody
	public String info() {
		return "<h1>Information Page <a href=\"/home\">Back</a></h1>";
	}

}