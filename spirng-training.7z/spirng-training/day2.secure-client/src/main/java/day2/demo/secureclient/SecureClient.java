package day2.demo.secureclient;

import java.nio.charset.Charset;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class SecureClient {

	public final static String BASE_URL = "http://localhost:8085/secure/";

	public static void main(String[] args) {
		restTemplateTest(BASE_URL + "m1");
		System.out.println("-------------------------------------------------");
		restTemplateTest(BASE_URL + "m2");
	}

	/** custom header where custom authenticating logic should be used */
	private static HttpHeaders createCustomHeaders(String username, String password) {
		// return new HttpHeaders() {
		// private static final long serialVersionUID = 8325657723099126257L;
		// String auth = username + ":" + password;
		// byte[] endcodedAuth =
		// Base64.getEncoder().encode(auth.getBytes(Charset.forName("US-ASCII")));
		// String authHeader = "Basic" + new String(endcodedAuth);
		//
		// @Override
		// public void set(String headerName, String headerValue) {
		// // TODO Auto-generated method stub 
		// super.set("Authorization", authHeader);
		// }
		// };

		return new HttpHeaders() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			{
				String auth = username + ":" + password;
				byte[] encodeAuth = org.springframework.security.crypto.codec.Base64
						.encode(auth.getBytes(Charset.forName("US-ASCII")));
				String authHeader = "Basic " + new String(encodeAuth);
				set("Authorization", authHeader);
			}
		};
	}

	private static void restTemplateTest(String url) {

		try {
			RestTemplate restTemplate = new RestTemplate();

			/** plain use of resttemplate */
			// ResponseEntity<String> response = restTemplate.getForEntity(url,
			// String.class);

			/** use of resttemplate with custom http header for authorization */
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET,
					new HttpEntity<>(createCustomHeaders("anirudha", "anirudha")), String.class);

			System.err.println(response);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

	}
}
