package hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@EnableDiscoveryClient
@SpringBootApplication
public class EurekaClientApplicationApp1 {

	public static void main(String[] args) {
		SpringApplication.run(EurekaClientApplicationApp1.class, args);
	}

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}

@Controller
class ServiceInstanceRestController {

	@Autowired
	private DiscoveryClient discoveryClient;

	@Autowired
	RestTemplate restTemplate;

	@RequestMapping(method = RequestMethod.GET, path = "/")
	public String home() {
		return "index.html";
	}

	@RequestMapping(method = RequestMethod.GET, path = "/add")
	@ResponseBody
	public String add(@RequestParam(name = "var1") int v1, @RequestParam(name = "var2") int v2) {

		String url = "http://app2";

		String response = restTemplate.getForObject(url + "/add?var1=" + v1 + "&var2=" + v2, String.class);
		System.err.println(response);
		return response;
	}

	@RequestMapping("/service-instances/{applicationName}")
	@ResponseBody
	public List<ServiceInstance> serviceInstancesByApplicationName(@PathVariable String applicationName) {
		return this.discoveryClient.getInstances(applicationName);
	}
}
